/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_447(unsigned x)
{
    return x + 2421737491U;
}

unsigned addval_320(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_194(unsigned x)
{
    return x + 3347662874U;
}

unsigned addval_106(unsigned x)
{
    return x + 3267856712U;
}

unsigned getval_427()
{
    return 3281012980U;
}

void setval_211(unsigned *p)
{
    *p = 2496104776U;
}

unsigned getval_151()
{
    return 2425393496U;
}

void setval_181(unsigned *p)
{
    *p = 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_249()
{
    return 3599305163U;
}

void setval_385(unsigned *p)
{
    *p = 2425411273U;
}

void setval_474(unsigned *p)
{
    *p = 2430650696U;
}

unsigned getval_408()
{
    return 3286272264U;
}

unsigned addval_245(unsigned x)
{
    return x + 3374372521U;
}

void setval_379(unsigned *p)
{
    *p = 3682912937U;
}

unsigned addval_406(unsigned x)
{
    return x + 3281174921U;
}

unsigned addval_298(unsigned x)
{
    return x + 3380134281U;
}

unsigned getval_312()
{
    return 3286272328U;
}

unsigned addval_139(unsigned x)
{
    return x + 3682126473U;
}

unsigned addval_420(unsigned x)
{
    return x + 3767101693U;
}

unsigned getval_145()
{
    return 3398021000U;
}

unsigned getval_376()
{
    return 3599603943U;
}

void setval_433(unsigned *p)
{
    *p = 3348158089U;
}

void setval_390(unsigned *p)
{
    *p = 3767093733U;
}

unsigned addval_103(unsigned x)
{
    return x + 3527983497U;
}

unsigned addval_303(unsigned x)
{
    return x + 348373385U;
}

unsigned getval_277()
{
    return 3281049241U;
}

unsigned addval_153(unsigned x)
{
    return x + 3221804681U;
}

void setval_231(unsigned *p)
{
    *p = 2462746980U;
}

unsigned addval_287(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_209(unsigned x)
{
    return x + 2425539209U;
}

unsigned getval_365()
{
    return 3247489417U;
}

void setval_480(unsigned *p)
{
    *p = 3252717896U;
}

void setval_461(unsigned *p)
{
    *p = 3682912969U;
}

void setval_363(unsigned *p)
{
    *p = 3767093365U;
}

unsigned getval_187()
{
    return 3374369417U;
}

unsigned addval_285(unsigned x)
{
    return x + 3397928363U;
}

void setval_250(unsigned *p)
{
    *p = 3352725979U;
}

unsigned getval_117()
{
    return 3281043848U;
}

unsigned getval_487()
{
    return 3525362057U;
}

unsigned addval_435(unsigned x)
{
    return x + 3281043848U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
